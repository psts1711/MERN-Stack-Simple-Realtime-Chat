export class chatController{
    static async index(req,res){
        res.send('server is up and running')
    }
}